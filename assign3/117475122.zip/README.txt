Xueqian Deng, Chujian Yu

Xueqian is responsible for writing c_hexfuncs and c_hexmain, wrote the unit tests
Chujian is responsible for debugging hexdump and write assembly code for asm func and asm main.

Both Xueqian and Chujian contributed equally to this assignment
