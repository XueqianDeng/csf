Xueqian Deng, Chujian Yu
 
<<<<<<< HEAD
Chujian Yu contribute to the helper methods and functionality of cache_funcs.cpp and cache_funcs.h. 
Xueqian Deng contribute to the main function. 

Chujian Yu and Xueqian Deng contributed equally in the tasks. 
=======
Xueqian is responsible for writing c_hexfuncs and c_hexmain, wrote the unit tests
Chujian is responsible for debugging hexdump and write assembly code for asm func and asm main.

Both Xueqian and Chujian contributed equally to this assignment
>>>>>>>
