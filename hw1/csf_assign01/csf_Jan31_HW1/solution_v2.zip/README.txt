Chujian Yu, Xueqian Deng

We worked together to write functions that create fixedpoint. 
For fixedpoint_create_from_hex, Xueqian Deng wrote the code validating input strings,
and Chujian Yu worked on the part splitting the strings. 