name: Chujian Yu and Xueqian Deng

Chujian Yu contributes to the original draft of fixedpoint.c, fixedpoints.h, and fixedpiont_tests.c.
Xueqian Deng contributes some of functions in fixedpoint.c
Xueqian Deng contributes to fixing bugs and add more tests in fixedpiont_tests.c.
Chujian Yu and Xueqian Deng contribute equally to Assignment 1.
