Xueqian Deng, Chujian Yu

Xueqian is responsible for writing c_hexfuncs and c_hexmain, wrote the unit tests, and contributed to asm_hexmain.
Chujian is responsible for debugging hexdump for edge cases and writing assembly code for asm func and asm main.


Both Xueqian and Chujian contributed equally to this assignment