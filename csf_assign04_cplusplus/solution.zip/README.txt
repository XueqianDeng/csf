TODO: describe the contributions of each team member

Xueqian Deng, Chujian Yu
 
Xueqian Deng contributed to functions that reads and summarizes the elf file.
Chujian Yu is responsible for debugging the program and the style/syntax.

Both Xueqian and Chujian contributed equally to this assignment